var searchData=
[
  ['encoderinitcount_681',['encoderInitCount',['../structmotor__descriptor.html#a72915ce678e349f71b7f019af8e56448',1,'motor_descriptor']]],
  ['encoderpreviouscount_682',['encoderPreviousCount',['../structmotor__descriptor.html#ad2b2d1b86d32ac3f32f403c5f8a80da2',1,'motor_descriptor']]],
  ['encodertimer_683',['encoderTimer',['../structmotor__descriptor.html#aa6eea81cc7c2c7da6cbcb22ce3addf1c',1,'motor_descriptor']]],
  ['encodertotalcount_684',['encoderTotalCount',['../structmotor__descriptor.html#a31f9bb0883bc941645a34c0bc8efbab8',1,'motor_descriptor']]],
  ['encodertotalinit_685',['encoderTotalInit',['../structmotor__descriptor.html#a60fd56094b7c18e51f07ce593be455d2',1,'motor_descriptor']]],
  ['encodertotalsetpoint_686',['encoderTotalSetpoint',['../structmotor__descriptor.html#aac7ceee4bf4e1f5d8f75566d0f1c4ebe',1,'motor_descriptor']]]
];
