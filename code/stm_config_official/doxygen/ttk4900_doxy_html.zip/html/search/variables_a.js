var searchData=
[
  ['nadc_705',['Nadc',['../structcurrent__measurement__descriptor.html#a0f8640d071d2f97033ee9145f07a61e2',1,'current_measurement_descriptor']]],
  ['newmsg_706',['newMsg',['../structcan__mailbox.html#aee7b998334d7ae5f003546db8080fda9',1,'can_mailbox']]],
  ['newxacc_707',['newXAcc',['../structaccelerometer__inData.html#a98a1845e11ade5c0557ae2c30ad2e445',1,'accelerometer_inData']]],
  ['newxrot_708',['newXRot',['../structaccelerometer__inData.html#a30d97139cd7edcd702a72874b591ab6a',1,'accelerometer_inData']]],
  ['newyacc_709',['newYAcc',['../structaccelerometer__inData.html#ace8ac7b2c73e65685042bae0f0a4880f',1,'accelerometer_inData']]],
  ['newyrot_710',['newYRot',['../structaccelerometer__inData.html#a05a5ebb6bbdbc12e27233d36e683f9d6',1,'accelerometer_inData']]],
  ['newzacc_711',['newZAcc',['../structaccelerometer__inData.html#a6efd71ec14de07917260981fc53baa4e',1,'accelerometer_inData']]],
  ['newzrot_712',['newZRot',['../structaccelerometer__inData.html#a01568e5c60d11ba9542082c10b42ff8e',1,'accelerometer_inData']]]
];
