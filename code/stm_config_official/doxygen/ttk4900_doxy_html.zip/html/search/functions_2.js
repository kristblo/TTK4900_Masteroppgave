var searchData=
[
  ['gpio_5fend_5fswitch_5fhandler_571',['gpio_end_switch_handler',['../gpio__driver_8h.html#a41616e7b18262c3ad5168679a2449651',1,'gpio_driver.h']]],
  ['gpio_5ftwist_5fswitch_5fhandler_572',['gpio_twist_switch_handler',['../gpio__driver_8h.html#ab33794872952dd8cf3f76aeb9f0888bc',1,'gpio_driver.h']]]
];
