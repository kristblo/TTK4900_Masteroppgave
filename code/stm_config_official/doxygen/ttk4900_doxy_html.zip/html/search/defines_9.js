var searchData=
[
  ['torso_799',['TORSO',['../unit__config_8h.html#a2b9b2c7507f05290eac2763bc18b5460',1,'unit_config.h']]]
];
