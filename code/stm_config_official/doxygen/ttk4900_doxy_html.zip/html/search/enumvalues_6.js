var searchData=
[
  ['pinch_5ftwist_5fsp_773',['PINCH_TWIST_SP',['../can__driver_8h.html#a54f5aea26986c68416e85e4c2f1151b8a5c8cd45f8ee05d752d20cf97b63954e7',1,'can_driver.h']]]
];
