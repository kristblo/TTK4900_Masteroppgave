var searchData=
[
  ['adc_677',['adc',['../structcurrent__measurement__descriptor.html#a1a1e9408484277aaa03d8d889705cea3',1,'current_measurement_descriptor']]],
  ['aipropi_678',['Aipropi',['../structcurrent__measurement__descriptor.html#a002aa46f0e9a6c0a1059658153aa6481',1,'current_measurement_descriptor']]]
];
