var searchData=
[
  ['lastmeasurement_698',['lastMeasurement',['../structcurrent__measurement__descriptor.html#a240f6e537aff605b52f1d2e7238b1c2f',1,'current_measurement_descriptor']]],
  ['lastreading_699',['lastReading',['../structcurrent__measurement__descriptor.html#a6416c00be20a18ffeb82e7e1b35965b6',1,'current_measurement_descriptor']]]
];
