var searchData=
[
  ['torqueconst_371',['torqueConst',['../structmotor__descriptor.html#a3a0446a631e8484adecc9fb71a31f6d5',1,'motor_descriptor']]],
  ['torso_372',['TORSO',['../unit__config_8h.html#a2b9b2c7507f05290eac2763bc18b5460',1,'unit_config.h']]]
];
