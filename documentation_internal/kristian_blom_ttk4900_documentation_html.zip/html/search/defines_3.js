var searchData=
[
  ['global_5fdebug_791',['GLOBAL_DEBUG',['../unit__config_8h.html#aaeee05cd2924a618c0f0dbffbcd889e5',1,'unit_config.h']]]
];
