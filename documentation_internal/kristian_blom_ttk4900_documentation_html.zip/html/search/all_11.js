var searchData=
[
  ['voltage_5fin_385',['VOLTAGE_IN',['../unit__config_8h.html#a6358b96ced1636f8f1e5b4e49856de68',1,'unit_config.h']]],
  ['voltagelimit_386',['voltageLimit',['../structmotor__descriptor.html#a65123b1652115d8da3b1a06db636655e',1,'motor_descriptor']]],
  ['voltagepctcap_387',['voltagePctCap',['../structmotor__descriptor.html#a88304ff60e84a9929253e2e361ae1c94',1,'motor_descriptor']]],
  ['vrefa_388',['VrefA',['../structcurrent__measurement__descriptor.html#a70e7869d48bb0e6f80b2a527dbbb2524',1,'current_measurement_descriptor']]]
];
