var searchData=
[
  ['readaddr_722',['readAddr',['../structimu__descriptor.html#a2302dfe0bdf416da03e413dd70735dd4',1,'imu_descriptor']]],
  ['resolution_723',['resolution',['../structmotor__descriptor.html#ad06fc0139cc26326e8ab4e5a1f15ed68',1,'motor_descriptor']]],
  ['ripropi_724',['Ripropi',['../structcurrent__measurement__descriptor.html#ada8e26587441279dace5efcbcf1bdbdd',1,'current_measurement_descriptor']]]
];
