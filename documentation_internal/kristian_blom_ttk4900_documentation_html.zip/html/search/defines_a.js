var searchData=
[
  ['uart_5finput_802',['UART_INPUT',['../unit__config_8h.html#ab8f859b67185930087f8fcd5844f882f',1,'unit_config.h']]],
  ['uart_5finterface_803',['UART_INTERFACE',['../unit__config_8h.html#ab0c126ca539372a99b2863c9612e1496',1,'unit_config.h']]],
  ['usb_5finterface_804',['USB_INTERFACE',['../unit__config_8h.html#a869bb2519c44f3825465da02616782c3',1,'unit_config.h']]]
];
