var searchData=
[
  ['enc1_192',['ENC1',['../unit__config_8h.html#a47effe741b3d2cdf70661fa3c461a553',1,'unit_config.h']]],
  ['enc2_193',['ENC2',['../unit__config_8h.html#aabbef3d461c514d1d64b78580faacf13',1,'unit_config.h']]],
  ['encoderinitcount_194',['encoderInitCount',['../structmotor__descriptor.html#a72915ce678e349f71b7f019af8e56448',1,'motor_descriptor']]],
  ['encoderpreviouscount_195',['encoderPreviousCount',['../structmotor__descriptor.html#ad2b2d1b86d32ac3f32f403c5f8a80da2',1,'motor_descriptor']]],
  ['encodertimer_196',['encoderTimer',['../structmotor__descriptor.html#aa6eea81cc7c2c7da6cbcb22ce3addf1c',1,'motor_descriptor']]],
  ['encodertotalcount_197',['encoderTotalCount',['../structmotor__descriptor.html#a31f9bb0883bc941645a34c0bc8efbab8',1,'motor_descriptor']]],
  ['encodertotalinit_198',['encoderTotalInit',['../structmotor__descriptor.html#a60fd56094b7c18e51f07ce593be455d2',1,'motor_descriptor']]],
  ['encodertotalsetpoint_199',['encoderTotalSetpoint',['../structmotor__descriptor.html#aac7ceee4bf4e1f5d8f75566d0f1c4ebe',1,'motor_descriptor']]]
];
